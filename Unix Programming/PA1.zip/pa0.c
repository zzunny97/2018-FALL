#include <fcntl.h>
#include <unistd.h>
#define MAX 500000

void Print(int val);

int check(char c){
   return ('a'<=c && c<='z') || ('A'<=c && c<='Z');
}

int check2(char c){
   return c=='!'|| c=='('|| c==')'|| c==','|| c=='.'|| c==':'|| c==';'|| c=='?' || c=='\n' || c==' ';
}

int check3(char c){
   return '0'<=c && c<='9';
}


int main(int argc, char **argv)
{
   int fd;
   const char *file_name = NULL;

   if (argc < 2) {
      write(1, "usage: pa0 <src>\n", 17);
      return 1;
   } else {
      file_name = argv[1];
   }

   fd = open(file_name, O_RDONLY);

   char buf[MAX];
   int chap=0, ver=0, cnt=0;
   int readn;

   readn=read(fd, buf, MAX-1);
   for(int i=1; i<readn; i++){
      if(buf[i-1]=='\n'){
         int buf_idx = i, flag=0;
         while(!check3(buf[buf_idx])){
            if(buf[buf_idx]=='\n'){
               flag=1; break;
            }
            buf_idx++;
         }
         if(flag==1) continue;
         char c[10]; int c_len=0;
         if(!(check3(buf[buf_idx+1])||buf[buf_idx+1]==':')){
            continue;
         }
         while(check3(buf[buf_idx])||buf[buf_idx]==':'||buf[buf_idx]==' '){
            c[c_len++] = buf[buf_idx++];
         }
         int tmp=0;
         int c_index=0;
         while(c[c_index]!=':'){
            tmp*=10;
            tmp+=c[c_index++]-'0';
         }
         chap+=tmp;
         tmp=0;
         while(!('0'<=c[c_index]&&c[c_index]<='9')){
            c_index++;
         }
         while(c[c_index]!=':'){
            tmp*=10;
            tmp+=c[c_index++]-'0';
         }
         ver+=tmp;

      }
   }

   for(int i=0; i<readn; i++){
      if(check3(buf[i])){
         while(!check(buf[i])){
            i++;
         }
         while(buf[i]!='\n'){
            if(check(buf[i])){
               cnt++;
               while(!(check2(buf[i]))){
                  i++;
               }
            } else{
               i++;
            }
         }
      }
   }

   Print(chap);
   write(1," ", 1);
   Print(ver);
   write(1," ", 1);
   Print(cnt);
   write(1, "\n", 1);
   close(fd);
   return 0;
}

void Print(int val)
{
   char a[10]; int index=0;
   while(val){
      int t = val%10;
      a[index++]=t+'0';
      val/=10;
   }
   a[index]='\0';
   int size=index;
   char temp;
   for (int i = 0; i < size / 2; i++){
      temp = a[i];
      a[i] = a[(size - 1) - i];
      a[(size - 1) - i] = temp;
   }
   write(1, &a, size);
}
