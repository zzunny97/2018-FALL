#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>

#define  BUF_SIZE 1024
#define MAX 500000

typedef enum {false, true} bool;

bool IsNumber(char a){
	if('0'<=a && a<='9')
		return true;
	else
		return false;
}

void keyword_searcher(char target[]);
void Print(int val);

// all txt files
// txt file descripter
int fd;
char buf[MAX];
long readn;
int server_socket, client_socket, client_addr_size;


int main(int argc, char const *argv[])
{

	int fd = open("genesis.txt", O_RDONLY);
	if (fd < 0) {
		perror("file not exists\n");
		exit(1);
	}
	readn = read(fd, buf, MAX-1);



	if(argc != 2)
	{
		perror("you didn't set port number\n");
		exit(1);
	}
	int port = atoi(argv[1]);
	char buf_recv[BUF_SIZE];


	struct sockaddr_in server_addr, client_addr;


	server_socket = socket(AF_INET, SOCK_STREAM, 0);
	if(server_socket == -1)
	{
		perror("failed to create server_socket\n");
		exit(1);
	}

	//server_socket의 정보를 저장
	memset(&server_addr, 0, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(port);
	server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");


	int enable = 1;
	if(setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int))<0)
	{
		perror("reuse error");
		exit(1);
	}
	// 커널정보에 서버소켓 정보를 넣어주는것이 bind
	if(bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr))<0)
	{
		perror("bind execute error\n");
		exit(1);
	}

	//printf("Started Server : %d\n", port);
	write(1, "Started Server: ", strlen("Started Server: "));
	Print(port);
	write(1, "\n\n\n", strlen("\n\n\n"));
	if(listen(server_socket, 5) == -1)
	{
		perror("failed to set wait state\n");
		exit(1);
	}
	client_addr_size = sizeof(client_addr);
	client_socket = accept(server_socket, (struct sockaddr*)&client_addr, (unsigned int*)&client_addr_size);
	if(client_socket < 0)
	{
		perror("client connect accept failed\n");
		exit(1);
	}
	write(1, "Connected: ", strlen("Connected: "));
	write(1, inet_ntoa(client_addr.sin_addr), strlen(inet_ntoa(client_addr.sin_addr)));
	write(1, "\n", strlen("\n"));


	while(1)
	{
		memset(buf_recv, 0, sizeof(buf_recv));
		read(client_socket, buf_recv, BUF_SIZE);
		if(strcmp(buf_recv, "!q\n") == 0)
		{
			write(1, "Disconnected: ", strlen("Disconnected: "));
			write(1, inet_ntoa(client_addr.sin_addr), strlen(inet_ntoa(client_addr.sin_addr)));
			write(1, "\n\n\n", strlen("\n\n\n"));
			close(client_socket);
			if(listen(server_socket, 5) == -1)
			{
				perror("failed to set wait state\n");
			}
			client_addr_size = sizeof(client_addr);
			client_socket = accept(server_socket, (struct sockaddr*)&client_addr, (unsigned int*)&client_addr_size);
			if(client_socket < 0)
			{
				perror("client connect accept failed\n");
			}
			//printf("Connected: %s\n", inet_ntoa(client_addr.sin_addr));
			write(1, "Connected: ", strlen("Connected: "));
			write(1, inet_ntoa(client_addr.sin_addr), strlen(inet_ntoa(client_addr.sin_addr)));
			write(1, "\n", strlen("\n"));
		}
		else
		{
			write(1, "search: ", strlen("search: "));
			write(1, buf_recv, strlen(buf_recv));
			write(1, "\n", strlen("\n"));
			//printf("search: %s\n", buf_recv);
			keyword_searcher(buf_recv);
		}

	}

	close(server_socket);
	return 0;
}

void keyword_searcher(char buf_recv[])
{
	char* target = (char*)malloc(sizeof(char)*BUF_SIZE);
	int a = strlen(buf_recv);
	for (int i = 0; i < a; ++i)
	{
		if(buf_recv[i] == ' ' || (('a' <= buf_recv[i] && buf_recv[i] <= 'z') || ('A' <= buf_recv[i] && buf_recv[i] <= 'Z'))
			|| buf_recv[i] == '\'' || buf_recv[i] == ':' || buf_recv [i] == '-')
		{
			target[i] = buf_recv[i];
		}
		else
		{
			break;
		}
	}


	//printf("target = %s\n", target);
	//printf("targetlen = %ld\n", strlen(target));

	for (int i = 0; i < readn; ++i)
	{
		if(IsNumber(buf[i]))
		{
			char* line = (char*)malloc(sizeof(char)*500);
			int line_idx = 0;
			while(1)
			{
				line[line_idx] = buf[i];
				if(buf[i] == '\n'){
					break;
				}
				i++;
				line_idx++;
			}
			line[line_idx+1] = '\0';
			int line_len = strlen(line);
			//printf("%s\n", line);

			int flag = 0;
			for(int k = 0; k<line_len; k++)
			{
				if(line[k] == ' ')
				{
					k++;
					for(int l = k; l < k+strlen(target); l++)
					{
						int target_start_idx = k;
						if(l == k+strlen(target)-1)
						{
							if(line[l] == target[l-k])
							{
								if(line[l+1] == ' ')
								{
									//push '[' and ']'
									flag = 1;
									for(int a = 500; a>=target_start_idx; a--)
									{
										line[a] = line[a-1];
									}
									line[target_start_idx] = '[';
									//printf("%s\n", line);
									for(int a = 500; a>=target_start_idx+strlen(target)+1; a--)
									{
										line[a] = line[a-1];
									}
									line[target_start_idx+strlen(target)+1] = ']';

									//printf("%s\n", line);
									continue;
								}
							}
						}
						else
						{
							if(line[l] == target[l-k]){
								continue;
							}
							else{
								//printf("break!!!\n");
								break;
							}
						}

					}
				}
			}

			if(flag == 1){
				//printf("genesis:%s\n", line);
				
				write(client_socket, "genesis:", strlen("genesis:"));
				write(client_socket, line, strlen(line));
				
			}



		}


	}
	sleep(1);
	write(client_socket, "\n\n", strlen("\n\n"));

}


void Print(int val)
{
	if(val == 0){
		write(1, "0", strlen("0"));
	}
	char a[10]; int index=0;
	while(val){
		int t = val%10;
		a[index++]=t+'0';
		val/=10;
	}
	a[index]='\0';
	int size=index;
	char temp;
	for (int i = 0; i < size / 2; i++){
		temp = a[i];
		a[i] = a[(size - 1) - i];
		a[(size - 1) - i] = temp;
	}
	write(1, &a, size);
}

