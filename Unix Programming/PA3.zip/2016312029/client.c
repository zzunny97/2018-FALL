#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>

#define SEND_BUF_SIZE 256
#define RECV_BUF_SIZE 1024


int main(int argc, char const *argv[])
{
	if(argc != 3)
	{
		//printf("argument set failed\n");
		perror("argument set failed\n");
		exit(1);
	}

	const char* ip_address = argv[1];
	int port = atoi(argv[2]);
	char buf_recv[RECV_BUF_SIZE+1];

	int server_socket;
	struct sockaddr_in server_addr;
	server_socket = socket(PF_INET, SOCK_STREAM, 0);
	if(server_socket == -1)
	{
		//printf("socket create failed\n");
		perror("socket create failed\n");
		exit(1);
	}

	memset(&server_addr, 0, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(port);
	server_addr.sin_addr.s_addr = inet_addr(ip_address);

	if(connect(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1)
	{
		//printf("connect failed\n");
		perror("connect failed\n");
		exit(1);
	}

	char keyword[SEND_BUF_SIZE];
	while(1)
	{
		memset(keyword, 0, SEND_BUF_SIZE);
		write(1, "> ", strlen("> "));
		read(0, keyword, SEND_BUF_SIZE);
		//keyword[strlen(keyword)] = '\n';
		//keyword[strlen(keyword)] = '\0';
		write(server_socket, keyword, strlen(keyword));
		if(strcmp(keyword, "!q\n") == 0)
		{
			close(server_socket);
			break;
		} 

		while(1)
		{
			//printf("!!!!!!!!!\n");
			memset(buf_recv, 0, RECV_BUF_SIZE+1);
			read(server_socket, buf_recv, RECV_BUF_SIZE+1);
			write(1, buf_recv, strlen(buf_recv));
			if(strcmp(buf_recv, "\n\n") == 0){
				//printf("???????????????????\n");
				break;
			}
			memset(buf_recv, 0, RECV_BUF_SIZE+1);
			read(server_socket, buf_recv, RECV_BUF_SIZE+1);
			write(1, buf_recv, strlen(buf_recv));
			if(strcmp(buf_recv, "\n\n") == 0){
				//printf("???????????????????\n");
				break;
			}
			else{
				
				continue;
			}

		}
	}



	return 0;
}



