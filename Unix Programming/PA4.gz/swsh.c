#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <pwd.h>

#define INPUT_SIZE 128

char** split(char* input);
int check(char* str);
int check2(char* str);
char* delete_symbol(char* str, char symbol);

char** split(char* input)
{
	char** input_tokenized;
	char input_copy[INPUT_SIZE];
	strcpy(input_copy, input);
	int token_num = 0;
	int idx = 0;

	//detect the number of token
	char* ptr = strtok(input, " \n");
	while(ptr!=NULL){
		ptr=strtok(NULL, " \n");
		token_num++;
	}

	//dynamic allocation
	input_tokenized = (char**)malloc(sizeof(char*)*(token_num+1));

	//put each token to input_tokenized
	char* ptr2 = strtok(input_copy, " \n");
	while(ptr2!=NULL){
		input_tokenized[idx] = (char*)malloc(sizeof(char)*(strlen(ptr2)+1));
		strcpy(input_tokenized[idx], ptr2);
		input_tokenized[idx][strlen(ptr2)]='\0';
		ptr2=strtok(NULL, " \n");
		idx++;
	}
	input_tokenized[token_num] = NULL;

	if(strcmp(input_tokenized[0], "echo")==0){
		for (int i = 0; i < token_num; ++i) {
			if(check2(input_tokenized[i])!=-1){
				delete_symbol(input_tokenized[i], '"');
			}
		}
	}

	// for (int i = 0; i < token_num+1; ++i)
	// {
	// 	printf("i= %d %s\n", i, input_tokenized[i]);
	// }
	return input_tokenized;
}

char* delete_symbol(char* str, char symbol)
{
	int len = strlen(str)+1;
	for (int i = 0; i < len; ++i) {
		if(str[i]=='"'){
			for(int j=i; str[j]!='\0'; j++){
				str[j] = str[j+1];
			}
		}
	}
	//printf("delete_symbol str: %s\n", str);
	return str;
}

int check(char* str)
{
	if(str==NULL)
		return -1;
	int len = strlen(str);
	//printf("total len: %d\n", strlen(str));
	for (int i = 0; i < len; ++i){
		//printf("str[%d]: %c\n", i, str[i]);
		if(str[i]=='|'){
			//printf("check function 종료\n");
			return i;
		}
	}
	return -1;
}

int check2(char* str)
{
	if(str==NULL)
		return -1;
	int len = strlen(str);
	//printf("total len: %d\n", strlen(str));
	for (int i = 0; i < len; ++i){
		//printf("str[%d]: %c\n", i, str[i]);
		if(str[i]=='"'){
			//printf("check function 종료\n");
			return i;
		}
	}
	return -1;
}

char* substr(char* str, int start, int end)
{
	int len = end - start + 1;
	char* substring = (char*)malloc(sizeof(char)*(end-start+2));

}

int main(int argc, char const *argv[])
{
	// signal(SIGINT, SIG_IGN);
	// signal(SIGTSTP, SIG_IGN);

	char input[INPUT_SIZE]="";
	char input_copy[INPUT_SIZE];
	char** input_tokenized;
	pid_t pid;
	int check_idx;

	while(true){
		wait(&pid);
		write(1, "$ ", strlen("$ "));
		fgets(input, INPUT_SIZE, stdin);
		// if(strcmp(input, "exit\n")==0){
		// 	exit(0);
		// }
		strcpy(input_copy, input);
		if(strcmp(input_copy, "\n")!=0)
			//printf("input_copy: %s\n", input_copy);
			if(strcmp(input, "\n")==0){
				continue;
			}
			else{
				input_tokenized = split(input);

				//printf("check(input): %d\n", check(input));
				check_idx = check(input_copy);
				if(check_idx!=-1){
					//printf("check_idx: %d\n", check_idx);
					//printf("-------------------PIPE-------------------\n");
					char* inst1 = strndup(input_copy, check_idx);
					char* inst2 = strdup(input_copy+strlen(inst1)+1);

					char** command1_tokenized = split(inst1);
					char** command2_tokenized = split(inst2);

					pid_t pid1, pid2;
					int pipefd[2];
					pipe(pipefd);
					int status = 0;

					if(pipe(pipefd)==-1){
						perror("pipelining error\n");
						exit(0);
					}
					if(pid1=fork()==0){
						dup2(pipefd[1], STDOUT_FILENO);
						close(pipefd[0]);
						close(pipefd[1]);
						execvp(command1_tokenized[0], command1_tokenized);

					}
					else if(pid2=fork()==0){
						dup2(pipefd[0], STDIN_FILENO);
						close(pipefd[0]);
						close(pipefd[1]);
						execvp(command2_tokenized[0], command2_tokenized);

					}
					else{
						close(pipefd[0]);
						close(pipefd[1]);
						waitpid(pid1, &status, 0);
						waitpid(pid2, &status, 0);
					}

				}
				else if(strcmp("cat", input_tokenized[0])==0){
					//printf("cat 명령어 처리\n");
					char cat_buf;
					int cat_fd = open(input_tokenized[1], O_RDONLY);

					while(read(cat_fd, &cat_buf, 1))
						write(1, &cat_buf, 1);
					close(cat_fd);
				}
				else if(strcmp("cp", input_tokenized[0])==0){
					//printf("cp 명령어 처리\n");
					char cp_buf;
					int cp_fd_read = open(input_tokenized[1], O_RDONLY);
					int cp_fd_write = open(input_tokenized[2], O_WRONLY|O_CREAT);

					while(read(cp_fd_read, &cp_buf, 1))
						write(cp_fd_write, &cp_buf, 1);
					close(cp_fd_read);
					close(cp_fd_write);
				}
				else if(strcmp("mv", input_tokenized[0])==0){
					//printf("mv 명령어 처리\n");
					char mv_buf;
					int mv_fd_read = open(input_tokenized[1], O_RDONLY);
					int mv_fd_write = open(input_tokenized[2], O_WRONLY|O_CREAT);

					while(read(mv_fd_read, &mv_buf, 1))
						write(mv_fd_write, &mv_buf, 1);
					close(mv_fd_read);
					close(mv_fd_write);
					unlink(input_tokenized[1]);
				}
				else if(strcmp("rm", input_tokenized[0])==0){
					//printf("rm 명령어 처리\n");
					unlink(input_tokenized[1]);
				}
				else if(strcmp("cd", input_tokenized[0])==0){
					//printf("cd 명령어 처리\n");
					struct passwd *pw;
					char* dst = input_tokenized[1];
					if(dst==NULL){
						pw = getpwuid(getuid());
						dst = pw->pw_dir;
					}
					chdir(dst);
				}
				else if(strcmp("pwd", input_tokenized[0])==0){
					//printf("pwd 명령어 처리\n");
					char pwd_buf[100];
					getcwd(pwd_buf, 100);
					printf("%s\n", pwd_buf);
				}
				else if(strcmp("exit", input_tokenized[0])==0){
					//printf("exit 명령어 처리\n");
					exit(0);
				}
				else if(strcmp("head", input_tokenized[0])==0){
					//printf("head 명령어 처리\n");
					int head_fd = open(input_tokenized[1], O_RDONLY);

					// if there is any option, it is handled by execvp
					if(head_fd<0){
						pid = fork();
						if(pid==0)
							execvp(input_tokenized[0], input_tokenized);
					}

					char head_buf;
					int head_flag = 0;
					while(read(head_fd, &head_buf, 1)){
						if(head_flag==10)
							break;
						write(1, &head_buf, 1);
						if(head_buf=='\n'){
							head_flag++;
						}
					}

					/*--------------------SIMPLE OPTION (e.g. head -(number) (filename) --------------------*/
					// printf("head 명령어 처리\n");
					// char* option = input_tokenized[1];
					// if(*option!='-'){
					// 	perror("head option error\n");
					//  exit(0);
					// }
					// int head_line = *(option+1)-'0';
					// int head_fd = open(input_tokenized[2], O_RDONLY);
					// char head_buf;
					// int head_flag = 0;
					// while(read(head_fd, &head_buf, 1)){
					// 	if(head_flag==head_line)
					// 		break;
					// 	write(1, &head_buf, 1);
					// 	if(head_buf=='\n'){
					// 		head_flag++;
					// 	}
					// }
				}
				else if(strcmp("tail", input_tokenized[0])==0){
					//printf("tail 명령어 처리\n");
					int tail_fd = open(input_tokenized[1], O_RDONLY);

					// if there is any option, it is handled by execvp
					if(tail_fd<0){
						pid = fork();
						if(pid==0)
							execvp(input_tokenized[0], input_tokenized);
					}


					char tail_buf;
					int tail_flag = 0;
					while(read(tail_fd, &tail_buf, 1)){
						if(tail_buf=='\n')
							tail_flag++;
					}
					//printf("tail_flag: %d\n", tail_flag);
					int tail_fd2 = open(input_tokenized[1], O_RDONLY);
					int tail_flag2 = 0;
					while(read(tail_fd2, &tail_buf, 1)){
						if(tail_buf=='\n'){
							if(tail_flag2 < tail_flag - 9){
								tail_flag2++;
								if(tail_flag2==tail_flag-9){
									break;
								}	
							}

						}
					}
					while(read(tail_fd2, &tail_buf, 1)){
						write(1, &tail_buf, 1);
					}
					/*--------------------SIMPLE OPTION (e.g. tail -(number) (filename) --------------------*/

					// printf("tail 명령어 처리\n");
					// int tail_fd = open(input_tokenized[1], O_RDONLY);
					// char* option = input_tokenized[1];
					// if(*option!='-'){
					// 	perror("tail option error\n");
					// 	exit(0);
					// }
					// int tail_line = *(option+1)-'0';
					// char tail_buf;
					// int tail_flag = 0;
					// while(read(tail_fd, &tail_buf, 1)){
					// 	if(tail_buf=='\n')
					// 		tail_flag++;
					// }
					// printf("tail_flag: %d\n", tail_flag);
					// int tail_fd2 = open(input_tokenized[1], O_RDONLY);
					// int tail_flag2 = 0;
					// while(read(tail_fd2, &tail_buf, 1)){
					// 	if(tail_buf=='\n'){
					// 		if(tail_flag2 < tail_flag-tail_line-1){
					// 			tail_flag2++;
					// 			if(tail_flag2==tail_flag-tail_line-1){
					// 				break;
					// 			}	
					// 		}

					// 	}
					// }
					// while(read(tail_fd2, &tail_buf, 1)){
					// 	write(1, &tail_buf, 1);
					// }

				}

				else{
					pid = fork();
					if(pid < 0){
						perror("fork fail\n");
					}
					else if(pid==0){
						execvp(input_tokenized[0], input_tokenized);
					}




				}

			}

	}
	return 0;
}
