//2016312029
//Hyeongjun Park
#include "indexBuilder.h"
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

int check(char c){
   return ('a'<=c && c<='z') || ('A'<=c && c<='Z');
}

int check2(char c){
   return c=='!'|| c==','|| c=='.'|| c==':'|| c==';'|| c=='?' || c=='\n';
}

int check3(char c){
   return '0'<=c && c<='9';
}



void indexBuilder(const char* inputFileNm, const char* indexFileNm)
{
   for(int i=0; i<N; i++){
      hash_table[i].name = NULL;
      hash_table[i].flag = 0;
      hash_table[i].count = 0;
      hash_table[i].list = NULL;
      hash_table[i].left = NULL;
      hash_table[i].right = NULL;
   }
   int inputfd = open(inputFileNm, O_RDONLY);
   int start, end;
   char buf[MAX];
   int readn = read(inputfd, buf, MAX-1);
   int info[3] = {0};
   for(int i=0; i<readn; i++){
      if(check3(buf[i])){
         int tmp = 0;
         char c[10]; int c_len = 0;
         int temp_flag = 0;
         while(temp_flag < 2){
            if(buf[i]==':')   temp_flag++;
            c[c_len++] = buf[i];
            i++;
         }
         int c_index = 0;
         while(c[c_index]!=':') {
            tmp *= 10;
            tmp += c[c_index++]-'0';
         }
         info[0] = tmp; tmp = 0;
         while(!check3(c[c_index]))
            c_index++;
         while(c[c_index]!=':') {
            tmp *= 10;
            tmp += c[c_index++]-'0';
         }
         info[1] = tmp; tmp = 0; verse_num++;
         while(!check(buf[i])){
          i++;
         }
         start = i;
         int fflag = 0;
         while(1){
            while(!check(buf[i])){
               if(buf[i]=='\n'){
                  fflag = 1;
                  break;
               }
               i++;
            }
            if(fflag==1)   break;   
            char word_name[20] = {0}; int word_len = 0;
            end = i; info[2] = end - start;
            while(check(buf[i]) || buf[i]=='-' || buf[i]=='\''){
               //capital->small
               if('A' <= buf[i] && buf[i] <= 'Z'){
                  word_name[word_len++] = buf[i++] + 32;
               }
               else{
                  word_name[word_len++] = buf[i++];
               }
            }
            word_name[word_len++] = '\0';
            word_count++;
            unsigned long hash_index = hash_function(word_name) % N;
            //search whether the hash has same word_name
            Search(&hash_table[hash_index], word_name, info);
         }
      }
   }
   chapter_num = info[0];
    close(inputfd);
      
}

unsigned long hash_function(char str[]){
    unsigned long hash = N;
    int c;
    while ((c = *(str++))){
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
    }
    return hash;
}



void Search(Index* root, char word_name[], int info[]){

  
   Index* cur = root; Index* parent = NULL;
   //no words in the hash
   if(root->flag == 0){
      CreateFirst(root, word_name, info);
   }

   //some words in hash
   else{
    while(cur != NULL){
      if(strcmp(word_name, cur->name) > 0){
   			parent = cur;
   			cur = cur->right;
   	  }
   		else if(strcmp(word_name, cur->name) < 0){
   			parent = cur;
   			cur = cur->left;
   		}
   		else{
   			break;
   		}
   	}
    
        //not in hash table yet, but hash table contains some words.
       if(cur==NULL){
        if(strcmp(word_name, parent->name) > 0){
          CreateRight(parent, word_name, info);
        }
        else{
          CreateLeft(parent, word_name, info);
        }
       }
       //already in hash table
       else{
        InsertInfo(cur, info);
       } 
    
      
   }
   
}

void CreateFirst(Index* root, char* word_name, int info[]){
  int len = (int)strlen(word_name);
  char* aaa = (char*)malloc(sizeof(char)*len);
  aaa = strcpy(aaa, word_name);
  root->flag = 1;
  root->name = aaa;
  root->count = 1;
  Record* a = (Record*)malloc(sizeof(Record));
  a->chap = info[0];
  a->ver = info[1];
  a->location = info[2];
  a->next = NULL;
  root->list = a;
  root->left = NULL;
  root->right = NULL;

}

void CreateRight(Index* parent, char* word_name, int info[]){
  int len = (int)strlen(word_name);
  char* aaa = (char*)malloc(sizeof(char)*len);
  aaa = strcpy(aaa, word_name);
	Index* new = (Index*)malloc(sizeof(Index));
  new->flag = 1;
	new->name = aaa;
	new->count = 1;
	Record* a = (Record*)malloc(sizeof(Record));
	a->chap = info[0];
	a->ver = info[1];
	a->location = info[2];
  a->next = NULL;
	new->list = a;
	new->left = NULL;
	new->right = NULL;
	parent->right = new;
}

void CreateLeft(Index* parent, char* word_name, int info[]){
  int len = (int)strlen(word_name);
  char* aaa = (char*)malloc(sizeof(char)*len);
  aaa = strcpy(aaa, word_name);
	Index* new = (Index*)malloc(sizeof(Index));
  new->flag = 1;
	new->name = aaa;
	new->count = 1;
	Record* a = (Record*)malloc(sizeof(Record));
	a->chap = info[0];
	a->ver = info[1];
	a->location = info[2];
  a->next = NULL;
	new->list = a;
	new->left = NULL;
	new->right = NULL;
	parent->left = new;
}

void InsertInfo(Index* cur, int info[]){
	 cur->count++;
   Record* a = cur->list;
   while(a->next!=NULL){
   	a = a->next;
   }
   Record* new = (Record*)malloc(sizeof(Record));
   new->chap = info[0];
   new->ver = info[1];
   new->location = info[2];
   new->next = NULL;
   a->next = new;
   
}

unsigned long strlen(const char *str){
    unsigned long len = 0;
    while(str[len] != '\0'){
      len++;
    }
    return len;
}
char* strcpy(char* cpystr, const char* str){
    int len = 0;
    while(str[len]!= '\0'){
        cpystr[len] = str[len];
        len++;
    }
    cpystr[len] = '\0';
    return cpystr;
}

int strcmp(const char* cmpstr1, const char* cmpstr2){
    int len1 = 0,len2 = 0;
    while(cmpstr1[len1] != '\0'){
      len1++;
    }
    while(cmpstr2[len2] != '\0'){
      len2++;
    }

    if(len1 > len2)
        return 1;
    else if(len1 < len2)
        return -1;
    else{
      for(int i=0; i<len1; i++){
        if(cmpstr1[i] > cmpstr2[i])
          return 1;
        else if(cmpstr1[i] < cmpstr2[i])
          return -1;
      }
    }  
    return 0;
}









