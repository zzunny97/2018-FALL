//2016312029
//Hyeongjun Park
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include "indexBuilder.h"


void Traverse(Index* hash);
void Print(int val);

int fd, rv;

void indexPrinter(const char* indexFileNm, const char* outputFileNm)
{
	fd = open(outputFileNm, O_WRONLY | O_CREAT | O_TRUNC, 0600);
	char* str = (char*)malloc(sizeof(char)*20);
	int i = 0;
	while(outputFileNm[i] != '_'){
		str[i] = outputFileNm[i];
		i++;
	}
	str[i] = '\0';
	rv = write(fd, str, strlen(str));
	rv = write(fd, " ", 1);
	Print(chapter_num);
	rv = write(fd, " ", 1);
	Print(verse_num);
	rv = write(fd, " ", 1);
	Print(word_count);
	rv = write(fd, "\n", 1);
	for(int i=0; i<N; i++){
		Traverse(&hash_table[i]);
	}

  close(fd);
}

void Traverse(Index* hash){
    if(hash->flag==0)
      return;
  rv = write(fd, hash->name, strlen(hash->name));
  rv = write(fd, ": ", 2);
    Print(hash->count);
    Record* a = hash->list;
    while(a!=NULL){
   rv = write(fd, ", ", 2);
    	Print(a->chap);
   rv = write(fd, ":", 1);
    	Print(a->ver);
   rv = write(fd, ":", 1);
    	Print(a->location);
    	a=a->next;
    }
  rv = write(fd, "\n", 1);
    if(hash->left!=NULL)
      Traverse(hash->left);
    if(hash->right!=NULL)
      Traverse(hash->right);
}

void Print(int val){
   char a[10]; int index=0;
   while(val){
      int t = val%10;
      a[index++]=t+'0';
      val/=10;
   }
   a[index]='\0';
   int size=index;
   char temp;
   for (int i = 0; i < size / 2; i++){
      temp = a[i];
      a[i] = a[(size - 1) - i];
      a[(size - 1) - i] = temp;
   }
 rv = write(fd, &a, size);
}
