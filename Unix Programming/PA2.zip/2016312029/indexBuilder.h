//2016312029
//Hyeongjun Park
#define MAX 500000
#define N 10000

typedef struct Record{
   int chap, ver, location;
   struct Record* next;
} Record;

typedef struct Index{
   char* name;
   int flag;
   int count;
   struct Record* list; //contains records
   struct Index* left; //next word
   struct Index* right;
} Index;

unsigned long hash_function(char str[]);
void Search(Index* root, char word_name[], int info[]);
void CreateFirst(Index* root, char* word_name, int info[]);
void CreateRight(Index* parent, char* word_name, int info[]);
void CreateLeft(Index* parent, char* word_name, int info[]);
void InsertInfo(Index* cur, int info[]);
int strcmp(const char* a, const char* b);
char* strcpy(char* dest, const char* src);
unsigned long strlen(const char* str);

Index hash_table[N];
int chapter_num;
int verse_num;
int word_count;