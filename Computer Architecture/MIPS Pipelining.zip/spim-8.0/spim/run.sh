make clean
make EXCEPTION_DIR=../CPU
