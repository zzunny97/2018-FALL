#include <stdio.h>
#include <stdlib.h>

typedef struct block{
	int* data;
	int dirty;
	int LRU;
}block;

typedef struct set{
	struct block* blockarr;
}set;

int write;


int search(set ptr[], int target, int set_num, int asso, int word_per_block)
{
	int hit = 0;
	int	targetset = (target/word_per_block)%set_num;
	for(int i=0; i<asso; i++){
		for(int j=0; j<word_per_block; j++){
			if(ptr[targetset].blockarr[i].data[j]==target){
				hit=1;
			}
		}
	}
	return hit;
}


void updateLRU(set ptr[], int target, int set_num, int asso, int word_per_block, int cnt)
{
	int targetset = (target/word_per_block)%set_num;
	for(int i=0; i<asso; i++){
		for(int j=0; j<word_per_block; j++){
			if(ptr[targetset].blockarr[i].data[j]==target){
				ptr[targetset].blockarr[i].LRU = cnt;
			}
		}
	}
}

int find_empty_idx(set ptr[], int targetset, int asso, int word_per_block)
{
	int flag = 0;
	for(int i=0; i<asso; i++){
		flag = 0;
		for(int j=0; j<word_per_block; j++){
			if(ptr[targetset].blockarr[i].data[j]!=0){
				flag = 1;
				break;
			}
		}
		if(flag==0){
			return i;
		}
	}
	return -1;
}

int find_LRU_idx(set ptr[], int targetset, int asso, int word_per_block)
{
	int idx = 0;
	for(int i=0; i<asso; i++){
		if(ptr[targetset].blockarr[i].LRU < ptr[targetset].blockarr[idx].LRU){
			idx = i;
		}
	}
	return idx;
}

void add(set ptr[], int target, int set_num, int asso, int word_per_block, int cnt)
{
	int targetset = (target/word_per_block)%set_num;
	int idx = find_empty_idx(ptr, targetset, asso, word_per_block);
	int tmp = target/word_per_block;
	int start = tmp*word_per_block;
	if(idx==-1){
		idx = find_LRU_idx(ptr, targetset, asso, word_per_block);
		for(int j=0; j<word_per_block; j++){
			ptr[targetset].blockarr[idx].data[j] = start+j;		
		}
	}
	else{
		for(int j=0; j<word_per_block; j++){
			ptr[targetset].blockarr[idx].data[j] = start+j;
		}
	}
	ptr[targetset].blockarr[idx].LRU=cnt;


}

int l1_add(set ptr[], int target, int set_num, int asso, int word_per_block, int cnt)
{
	int targetset = (target/word_per_block)%set_num;
	int idx = find_empty_idx(ptr, targetset, asso, word_per_block);
	int tmp = target/word_per_block;
	int start = tmp*word_per_block;
	if(idx==-1){
		idx = find_LRU_idx(ptr, targetset, asso, word_per_block);
		int victim[word_per_block];
		for(int j=0; j<word_per_block; j++){
			victim[j] = ptr[targetset].blockarr[idx].data[j];
			ptr[targetset].blockarr[idx].data[j] = start+j;
		}
		ptr[targetset].blockarr[idx].LRU=cnt;
		return victim[0];
	}
	else{
		for(int j=0; j<word_per_block; j++){
			ptr[targetset].blockarr[idx].data[j] = start+j;
		}
	}
	ptr[targetset].blockarr[idx].LRU=cnt;

	return -1;

}




void rremove(set ptr[], int target, int set_num, int asso, int word_per_block)
{
	int targetset = (target/word_per_block)%set_num;
	int flag=0;
	int fflag=0;
	for(int i=0; i<asso; i++){
		for(int j=0; j<word_per_block; j++){
			if(ptr[targetset].blockarr[i].data[j]==target){
				for(int k=0; k<word_per_block; k++){
					ptr[targetset].blockarr[i].data[k]=0;
				}
				flag=1; fflag=1;
			}
			if(flag==1)
				break;
		}
		if(fflag==1)
			break;
	}
}

void inclusive(int l1_cache_size, int block_size, int asso, char filename[])
{
	write=0;
	int l1_i_set_num = (l1_cache_size/(asso*block_size))/2;
	int l1_d_set_num = (l1_cache_size/(asso*block_size))/2;
	int l2_set_num = 16384/(8*block_size);
	//int l1_i[l1_i_set_num][asso][block_size/4];
	//int l1_d[l1_d_set_num][asso][block_size/4];
	//int l2[l2_set_num][8][block_size/4];

	set l1_i[l1_i_set_num];
	for(int i=0; i<l1_i_set_num; i++){
		l1_i[i].blockarr = (block*)malloc(sizeof(block)*asso);
		for(int j=0; j<asso; j++){	
			l1_i[i].blockarr[j].dirty = 0;
			l1_i[i].blockarr[j].LRU = 0;
			l1_i[i].blockarr[j].data = (int*)malloc(4*block_size/4);
			for(int k=0; k<block_size/4; k++){
				l1_i[i].blockarr[j].data[k] = 0;
			}
		}
	}

	set l1_d[l1_d_set_num];
	for(int i=0; i<l1_d_set_num; i++){
		l1_d[i].blockarr = (block*)malloc(sizeof(block)*asso);
		for(int j=0; j<asso; j++){	
			l1_d[i].blockarr[j].dirty = 0;
			l1_d[i].blockarr[j].LRU = 0;
			l1_d[i].blockarr[j].data = (int*)malloc(4*block_size/4);
			for(int k=0; k<block_size/4; k++){
				l1_d[i].blockarr[j].data[k] = 0;
			}
		}
	}

	set l2[l2_set_num];
	for(int i=0; i<l2_set_num; i++){
		l2[i].blockarr = (block*)malloc(sizeof(block)*8);
		for(int j=0; j<8; j++){	
			l2[i].blockarr[j].dirty = 0;
			l2[i].blockarr[j].LRU = 0;
			l2[i].blockarr[j].data = (int*)malloc(4*block_size/4);
			for(int k=0; k<block_size/4; k++){
				l2[i].blockarr[j].data[k] = 0;
			}
		}
	}
	//int l1_i[l1_i_set_num][asso][block_size/4];
	int l1_set_num = l1_i_set_num;
	char buf[20];
	int target;
	int option;
	int cnt;
	int targetset;
	set* ptr;
	FILE* stream = fopen(filename, "r");
	int l1_i_hitcnt=0;
	int l1_i_misscnt=0;
	int l1_d_hitcnt=0;
	int l1_d_misscnt=0;
	int l2hitcnt=0;
	int l2misscnt=0;
	while(!feof(stream)){
		fscanf(stream, "%d %s", &option, buf);	cnt++;
		int l1hit=0;
		int l2hit=0;
		target=(int)strtol(buf, NULL, 16);

		if(option==0 || option==1){
			l1hit = search(l1_d, target, l1_d_set_num, asso, block_size/4);
			if(l1hit==1)
				l1_d_hitcnt++;
			else
				l1_d_misscnt++;
			ptr = l1_d;
		}
		else if(option==2){
			l1hit = search(l1_i, target, l1_i_set_num, asso, block_size/4);
			if(l1hit==1)
				l1_i_hitcnt++;
			else
				l1_i_misscnt++;
			ptr = l1_i;
		}
		if(l1hit==1){
			// update the LRU of the target cache block
			updateLRU(ptr, target, l1_i_set_num, asso, block_size/4, cnt);
		}
		//l1hit = 0, that is l1 miss
		else{
			//now we check the l2 hit, miss
			l2hit = search(l2, target, l2_set_num, 8, block_size/4);
			if(l2hit==1){
				l2hitcnt++;
				// add the block into l1 cache, update the LRU of target l2 block
				if(option==0 || option==1){
					ptr = l1_d;
				}
				else{
					ptr = l1_i;
				}
				int victim = l1_add(ptr, target, l1_set_num, asso, block_size/4, cnt);
				if(ptr==l1_d) write++;
				if(victim!=-1){
					int a = search(l2, victim, l2_set_num, 8, block_size/4);
					if(a){
						add(l2, victim, l2_set_num, 8, block_size/4, cnt);
					}
				}
				updateLRU(l2, target, l2_set_num, 8, block_size/4, cnt);
			}
			else{
				l2misscnt++;
				//add the block to l1 and l2 cache
				if(option==0 || option==1){
					ptr = l1_d;
				}
				else{
					ptr = l1_i;
				}
				int victim = l1_add(ptr, target, l1_set_num, asso, block_size/4, cnt);
				if(ptr==l1_d) write++;
				if(victim!=-1){
					int a = search(l2, victim, l2_set_num, 8, block_size/4);
					if(a){
						add(l2, victim, l2_set_num, 8, block_size/4, cnt);
					}
				}
				add(l2, target, l2_set_num, 8, block_size/4, cnt);
			}
		}
	}

	printf("%s\tL1size: %d\tblocksize: %d\tassociativities: %d>>> ", filename,l1_cache_size, block_size, asso);
	float l1_i_missratio = (float)l1_i_misscnt/(float)(l1_i_misscnt+l1_i_hitcnt);
	float l1_d_missratio = (float)l1_d_misscnt/(float)(l1_d_misscnt+l1_d_hitcnt);
	float l2_missratio = (float)l2misscnt/(float)(l2hitcnt+l2misscnt);
	printf("l1_i_miss: %f\tl1_d_miss: %f\t#write=%d\n", l1_i_missratio, l1_d_missratio, write);


}

void exclusive(int l1_cache_size, int block_size, int asso, char filename[])
{
	write=0;
	int l1_i_set_num = (l1_cache_size/(asso*block_size))/2;
	int l1_d_set_num = (l1_cache_size/(asso*block_size))/2;
	int l2_set_num = 16384/(8*block_size);
	//int l1_i[l1_i_set_num][asso][block_size/4];
	//int l1_d[l1_d_set_num][asso][block_size/4];
	//int l2[l2_set_num][8][block_size/4];

	set l1_i[l1_i_set_num];
	for(int i=0; i<l1_i_set_num; i++){
		l1_i[i].blockarr = (block*)malloc(sizeof(block)*asso);
		for(int j=0; j<asso; j++){	
			l1_i[i].blockarr[j].dirty = 0;
			l1_i[i].blockarr[j].LRU = 0;
			l1_i[i].blockarr[j].data = (int*)malloc(4*block_size/4);
			for(int k=0; k<block_size/4; k++){
				l1_i[i].blockarr[j].data[k] = 0;
			}
		}
	}

	set l1_d[l1_d_set_num];
	for(int i=0; i<l1_d_set_num; i++){
		l1_d[i].blockarr = (block*)malloc(sizeof(block)*asso);
		for(int j=0; j<asso; j++){	
			l1_d[i].blockarr[j].dirty = 0;
			l1_d[i].blockarr[j].LRU = 0;
			l1_d[i].blockarr[j].data = (int*)malloc(4*block_size/4);
			for(int k=0; k<block_size/4; k++){
				l1_d[i].blockarr[j].data[k] = 0;
			}
		}
	}

	set l2[l2_set_num];
	for(int i=0; i<l2_set_num; i++){
		l2[i].blockarr = (block*)malloc(sizeof(block)*8);
		for(int j=0; j<8; j++){	
			l2[i].blockarr[j].dirty = 0;
			l2[i].blockarr[j].LRU = 0;
			l2[i].blockarr[j].data = (int*)malloc(4*block_size/4);
			for(int k=0; k<block_size/4; k++){
				l2[i].blockarr[j].data[k] = 0;
			}
		}
	}
	//int l1_i[l1_i_set_num][asso][block_size/4];
	int l1_set_num = l1_i_set_num;
	char buf[20];
	int target;
	int option;
	int cnt;
	int targetset;
	set* ptr;
	FILE* stream = fopen(filename, "r");
	int l1_i_hitcnt=0;
	int l1_i_misscnt=0;
	int l1_d_hitcnt=0;
	int l1_d_misscnt=0;
	int l2hitcnt=0;
	int l2misscnt=0;
	while(!feof(stream)){
		fscanf(stream, "%d %s", &option, buf);	cnt++;
		int l1hit=0;
		int l2hit=0;
		target=(int)strtol(buf, NULL, 16);

		if(option==0 || option==1){
			l1hit = search(l1_d, target, l1_d_set_num, asso, block_size/4);
			if(l1hit==1)
				l1_d_hitcnt++;
			else
				l1_d_misscnt++;
			ptr = l1_d;
		}
		else if(option==2){
			l1hit = search(l1_i, target, l1_i_set_num, asso, block_size/4);
			if(l1hit==1)
				l1_i_hitcnt++;
			else
				l1_i_misscnt++;
			ptr = l1_i;
		}
		if(l1hit==1){
			// update the LRU of the target cache block
			updateLRU(ptr, target, l1_i_set_num, asso, block_size/4, cnt);
		}
		//l1hit = 0, that is l1 miss
		else{
			//now we check the l2 hit, miss
			l2hit = search(l2, target, l2_set_num, 8, block_size/4);
			if(l2hit==1){
				l2hitcnt++;
				// add the block into l1 cache, update the LRU of target l2 block
				if(option==0 || option==1){
					ptr = l1_d;
				}
				else{
					ptr = l1_i;
				}
				int victim = l1_add(ptr, target, l1_set_num, asso, block_size/4, cnt);
				if(ptr==l1_d)	write++;
				if(victim!=-1){
					int a = search(l2, victim, l2_set_num, 8, block_size/4);
					if(a){
						add(l2, victim, l2_set_num, 8, block_size/4, cnt);
					}
					updateLRU(l2, victim, l2_set_num, 8, block_size/4, cnt);
				}
				rremove(l2, target, l2_set_num, 8, block_size/4);
			}
			else{
				l2misscnt++;
				//add the block to l1 and l2 cache
				if(option==0 || option==1){
					ptr = l1_d;
				}
				else{
					ptr = l1_i;
				}
				int victim = l1_add(ptr, target, l1_set_num, asso, block_size/4, cnt);
				if(ptr==l1_d)	write++;
				if(victim!=-1){
					int a = search(l2, victim, l2_set_num, 8, block_size/4);
					if(a){
						add(l2, victim, l2_set_num, 8, block_size/4, cnt);
					}
					updateLRU(l2, victim, l2_set_num, 8, block_size/4, cnt);
				}
			}
		}
	}

	printf("%s\tL1size: %d\tblocksize: %d\tassociativities: %d>>> ", filename,l1_cache_size, block_size, asso);
	float l1_i_missratio = (float)l1_i_misscnt/(float)(l1_i_misscnt+l1_i_hitcnt);
	float l1_d_missratio = (float)l1_d_misscnt/(float)(l1_d_misscnt+l1_d_hitcnt);
	float l2_missratio = (float)l2misscnt/(float)(l2hitcnt+l2misscnt);
	printf("l1_i_miss: %f\tl1_d_miss: %f\t#write: %d\n", l1_i_missratio, l1_d_missratio, write);


}


int main(int argc, char* argv[]){
	int l1_cache_size[5] = {1024, 2048, 4096, 8192,	16384};
	int	block_size[2] =	{16, 64};
	int asso[4] = {1, 2, 4, 8};


	char file1[] = "trace1.din";
	char file2[] = "trace2.din";
	char file3[] = "trace1-short.din";
	char file4[] = "trace2-short.din";
	char testfile[] = "simple.din";

	printf("trace1.din inclusive\n");
	for(int i=0; i<5; i++){
		for(int j=0; j<2; j++){
			for(int k=0; k<4; k++){
				inclusive(l1_cache_size[i], block_size[j], asso[k], file1);
			}
		}
	}
	printf("trace1.din exclusive\n");
	for(int i=0; i<5; i++){
		for(int j=0; j<2; j++){
			for(int k=0; k<4; k++){
				exclusive(l1_cache_size[i], block_size[j], asso[k], file1);
			}
		}
	}
	printf("trace2.din inclusive\n");
	for(int i=0; i<5; i++){
		for(int j=0; j<2; j++){
			for(int k=0; k<4; k++){
				inclusive(l1_cache_size[i], block_size[j], asso[k], file2);
			}
		}
	}
	printf("trace2.din exclusive\n");
	for(int i=0; i<5; i++){
		for(int j=0; j<2; j++){
			for(int k=0; k<4; k++){
				exclusive(l1_cache_size[i], block_size[j], asso[k], file2);
			}
		}
	}






	return 0;
}
